package com.bridgelabz.fundooapp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringbootfundooApplicationTests {

	@Test
	void contextLoads() {
	}

}
